# Texto inicial para a Google Play

## Nome
Calistenia Evolution

## Descrição curta (rascunho)
Treinos de calistenia, exercícios ilustrados e vídeos offline para acompanhar sua evolução.

## Descrição completa (rascunho)
Evolua no seu ritmo com o Calistenia Evolution: uma biblioteca de exercícios de peso corporal, rotinas organizadas por objetivo e nível, instruções de execução e acompanhamento de progresso.

**O que você encontra:**
- Exercícios para diferentes grupos musculares e níveis.
- Instruções de execução, séries, repetições e descanso sugerido.
- Demonstrações em vídeo offline para movimentos selecionados.
- Rotinas para corpo inteiro, abdômen, condicionamento, pernas e mais.
- Histórico local para acompanhar treinos e minutos acumulados.
- Área Evolution Premium planejada para planos e desafios avançados.

Comece com movimentos adequados ao seu nível e avance gradualmente. O aplicativo tem finalidade informativa e não substitui orientação médica ou de profissional de educação física.

**Observação:** antes de publicar, atualize este texto para corresponder exatamente às funcionalidades finais. A área Premium nesta versão é demonstrativa e ainda não aceita pagamentos.

## Recursos gráficos
- Ícone: `icon-512.png` (512 × 512 px).
- Imagem promocional: `feature-graphic-1024x500.png` (1024 × 500 px).
- Capturas de tela: ainda precisam ser capturadas de uma compilação real e final do aplicativo.
