# Publicar o Calistenia Evolution usando apenas o iPhone

Este projeto inclui a versão web, 18 ilustrações originais, quatro vídeos MP4 curtos incluídos localmente (flexão, agachamento, prancha e polichinelo), a área Premium demonstrativa e fluxos de compilação Android em nuvem.

> **Importante:** esta é uma versão preparada para compilação, não um AAB já compilado ou publicado. A área Premium ainda não processa pagamentos. Não venda planos até integrar e testar o Google Play Billing.

## Etapa A — Criar um repositório pelo Safari

1. Abra https://github.com/ e crie uma conta ou entre na sua conta.
2. Crie um repositório novo chamado `calistenia-evolution-v2`. Para facilitar, deixe-o **Private**.
3. Na página do repositório, escolha **Add file → Upload files** e envie o arquivo `calistenia-evolution-v2.zip` que contém este projeto. Faça commit do arquivo ZIP.
4. Abra o menu **Code → Codespaces → Create codespace on main**. Isso abre um ambiente de desenvolvimento na nuvem no navegador; não precisa instalar ferramentas no iPhone.
5. No terminal do Codespace, execute os comandos abaixo. Se o ZIP tiver outro nome, ajuste a primeira linha:

```bash
unzip -o calistenia-evolution-v2.zip -d /tmp/ce-v2
cp -R /tmp/ce-v2/. .
rm calistenia-evolution-v2.zip
git add .
git commit -m "Prepare Calistenia Evolution v2"
git push
```

Se o GitHub não mostrar a opção Codespaces, abra **Settings → Codespaces** do repositório ou consulte a disponibilidade da sua conta. O Codespaces pode ter limites de uso gratuitos.

## Etapa B — Baixar uma versão de teste Android

Depois do `git push`:

1. No repositório, abra a aba **Actions**.
2. Entre na execução **Build Android test APK** que começou após o envio.
3. Espere a execução terminar com sucesso.
4. Na área **Artifacts**, baixe `calistenia-evolution-debug-apk`.
5. Extraia o ZIP do artefato para obter `app-debug.apk`. Esse APK é para testes em um aparelho Android; não é o arquivo para enviar como publicação final à Play Store.

O workflow gera o projeto Android em nuvem e usa Capacitor 8, alinhado ao Android 16 / API 36. A Google Play exige API 36 para novos apps e atualizações desde 31 de agosto de 2026.

## Etapa C — Preparar a assinatura do AAB de publicação

O arquivo da Play Store precisa ser assinado. **Nunca perca o arquivo de chave de envio nem as senhas.** Perder a chave pode impedir atualizações futuras se a recuperação da chave não estiver disponível.

1. No Codespace, verifique se o Java está disponível: `keytool -help`.
2. Gere uma chave de envio privada no terminal do Codespace. Escolha uma senha forte e guarde-a em um gerenciador de senhas. Substitua os valores entre `<>`:

```bash
keytool -genkeypair -v -keystore upload-key.jks -alias calistenia-upload -keyalg RSA -keysize 2048 -validity 10000
base64 -w 0 upload-key.jks
```

3. Copie a saída inteira do comando `base64` e adicione estes quatro **Repository secrets** em **Settings → Secrets and variables → Actions → New repository secret**:
   - `KEYSTORE_BASE64`: texto completo retornado pelo comando `base64`.
   - `KEYSTORE_PASSWORD`: senha que você definiu para o arquivo JKS.
   - `KEY_ALIAS`: `calistenia-upload` (ou o alias que você escolheu).
   - `KEY_PASSWORD`: senha da chave que você definiu no `keytool`.
4. Guarde uma cópia segura de `upload-key.jks` fora do repositório. **Não faça commit dessa chave, não a envie em mensagens e não publique as senhas.**
5. Na aba **Actions**, escolha **Build signed Google Play AAB → Run workflow**. Quando terminar, baixe o artefato `calistenia-evolution-release-aab` e extraia `app-release.aab`.

Se o terminal não reconhecer `keytool`, instale/ative um JDK no ambiente Codespaces antes de continuar. Não coloque o arquivo `.jks` no repositório.

## Etapa D — Criar o app na Play Console

1. Abra https://play.google.com/console/ e crie a conta de desenvolvedor. A inscrição custa US$ 25 uma única vez, além de verificações de identidade exigidas pelo Google.
2. Crie o app com o nome **Calistenia Evolution** e idioma padrão Português (Brasil).
3. Preencha a ficha da loja, classificação indicativa, público-alvo, segurança dos dados e demais declarações. Confira a política de privacidade antes de publicar.
4. Envie `app-release.aab` para um teste interno primeiro. Corrija falhas antes de abrir o teste fechado.
5. Para contas pessoais criadas após 13/11/2023, o Google exige um teste fechado com pelo menos 12 participantes inscritos continuamente por 14 dias antes de solicitar acesso à produção.

## Etapa E — Política de privacidade

O arquivo `www/privacy.html` é um rascunho para esta versão e ainda contém um marcador para inserir seu e-mail de contato. Antes de enviar à Play Store:

1. Substitua `[inserir e-mail de contato do desenvolvedor]` por um endereço válido.
2. Publique `privacy.html` em um endereço HTTPS acessível publicamente (por exemplo, GitHub Pages, depois de configurar a página).
3. Cole o endereço público da política na Play Console.

Revise as declarações de segurança dos dados para refletir a versão final. Se adicionar analytics, anúncios, login ou cobrança, atualize a política e as declarações.

## O que já está / o que ainda falta

- **Incluído:** 18 ilustrações vetoriais originais; vídeos offline MP4 para quatro movimentos; instruções e prescrições; biblioteca e rotinas; histórico local; área Premium demonstrativa; workflows de APK de teste e AAB assinado.
- **Ainda falta:** fotos reais licenciadas (as imagens atuais são ilustrações originais, não fotografias); integração real com Google Play Billing; e-mail e URL pública de privacidade; testes em aparelhos Android; capturas de tela finais e revisão das declarações da Play Console.
- **Não concluído automaticamente:** não foi criado um AAB assinado nem enviado nada para sua conta Google Play. Isso acontece depois de executar os passos acima com suas próprias contas e chaves.
