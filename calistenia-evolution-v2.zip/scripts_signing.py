from pathlib import Path
import re
p=Path('android/app/build.gradle')
s=p.read_text()
if 'signingConfigs {' not in s:
    insert='''    signingConfigs {
        release {
            storeFile file(System.getenv('CE_KEYSTORE_PATH'))
            storePassword System.getenv('CE_KEYSTORE_PASSWORD')
            keyAlias System.getenv('CE_KEY_ALIAS')
            keyPassword System.getenv('CE_KEY_PASSWORD')
        }
    }

'''
    s=s.replace('    buildTypes {',insert+'    buildTypes {',1)
# Only target the release block inside buildTypes, not signingConfigs.release
pattern=r'(buildTypes\s*\{[\s\S]*?release\s*\{)'
match=re.search(pattern,s)
if not match:
    raise SystemExit('Could not find buildTypes.release in generated Gradle file')
release_start=match.end()
rest=s[release_start:]
if 'signingConfig signingConfigs.release' not in rest.split('}',1)[0]:
    s=s[:release_start]+"\n            signingConfig signingConfigs.release"+s[release_start:]
p.write_text(s)
print('Signing configuration prepared.')
