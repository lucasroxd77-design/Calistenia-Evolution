# Calistenia Evolution v2

Aplicativo mobile-first de calistenia, preparado para Capacitor 8 e Android 16 (API 36).

## Recursos
- 18 exercícios com instruções, séries, repetições e descanso.
- 18 ilustrações vetoriais originais locais.
- Quatro vídeos demonstrativos MP4 empacotados no app para uso offline: flexão, agachamento, prancha e polichinelo.
- Oito rotinas e registro de progresso local.
- Área Premium demonstrativa com rotinas avançadas bloqueadas.
- Política de privacidade em rascunho em `www/privacy.html`.
- Workflow GitHub Actions para APK de teste e workflow manual para AAB assinado.

## Executar localmente
Requer Node.js 22 ou superior.

```bash
npm install
npm run start
```

## Android
Os workflows criam a plataforma Android em nuvem usando Capacitor 8. Consulte `CLOUD_BUILD_IPHONE.md` para o procedimento usando Safari/iPhone, assinatura e envio para a Play Console.

## Avisos de publicação
- Os vídeos são demonstrações esquemáticas originais, não substituem orientação profissional.
- As imagens incluídas são ilustrações, não fotos reais.
- A tela Premium ainda não integra Google Play Billing. Não habilite cobrança até implementar e testar compras/assinaturas pela biblioteca oficial.
- Atualize a política de privacidade e adicione um e-mail de contato antes da publicação.
- A compilação e a publicação não foram executadas automaticamente neste pacote.
