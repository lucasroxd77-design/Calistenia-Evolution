# Calistenia Evolution — iOS

Este projeto usa Capacitor, que permite reaproveitar a interface web do app no iOS e Android.

## Requisitos para compilar iOS
- Um Mac com uma versão atual do macOS
- Xcode instalado (pela Mac App Store)
- Node.js LTS e npm
- Conta Apple Developer para distribuição na App Store (a assinatura e publicação exigem configuração Apple)

## Adicionar iOS ao projeto
No terminal, dentro da pasta do projeto:

```bash
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```

O comando `npx cap open ios` abre o projeto no Xcode.

## Testar no simulador ou iPhone
1. No Xcode, escolha um simulador iPhone ou conecte seu aparelho.
2. Configure o identificador do app (Bundle Identifier), por exemplo `com.calisteniaevolution.app`.
3. Em **Signing & Capabilities**, selecione seu Team de desenvolvimento Apple e deixe o Xcode configurar a assinatura.
4. Execute no simulador ou no aparelho para testar.
5. Teste navegação, salvamento do histórico, tamanhos de tela, acessibilidade e funcionamento offline.

## Publicar na App Store
1. Entre no Apple Developer Program, se necessário.
2. Configure nome, ícone, screenshots, classificação etária e informações de privacidade.
3. No Xcode, selecione um destino genérico de iOS e use **Product > Archive**.
4. No Organizer, valide e envie o build para o App Store Connect.
5. Preencha a ficha no App Store Connect e envie para revisão.

## Importante
- Não é possível compilar ou assinar um app iOS final diretamente em Windows; o build e a assinatura iOS precisam do Xcode em um Mac ou de um serviço de build em nuvem compatível.
- Este repositório contém o código-fonte multiplataforma, não um arquivo `.ipa` assinado nem um app já publicado.
- A Apple pode exigir ajustes de política de privacidade, acessibilidade, metadados e conformidade antes de aprovar a publicação.
